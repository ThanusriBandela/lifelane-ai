// Initialize map
let map = L.map('map').setView([17.3850, 78.4867], 12);

// Add OSM tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19
}).addTo(map);

let vehicleMarkers = [];
let routeLayer;

// Function to fetch vehicle data from backend
async function fetchVehicles() {
  try {
    const res = await fetch('/vehicles');
    const data = await res.json();
    return data;
  } catch (err) {
    console.error(err);
    return [];
  }
}

// Function to add markers
function updateVehicles(vehicles) {
  // Remove old markers
  vehicleMarkers.forEach(m => map.removeLayer(m));
  vehicleMarkers = [];

  vehicles.forEach(v => {
    const marker = L.marker([v.lat, v.lng], {
      icon: L.icon({
        iconUrl: v.type === 'emergency' ? 'assets/icons/ambulance.png' : 'assets/icons/vehicle.png',
        iconSize: [30, 30]
      })
    }).addTo(map)
      .bindPopup(`${v.name} (${v.type})`);

    vehicleMarkers.push(marker);
  });
}

// Function to find route
async function findRoute() {
  const source = document.getElementById('source').value.split(',');
  const dest = document.getElementById('destination').value.split(',');

  if (!source[0] || !dest[0]) {
    alert('Enter source and destination in Lat,Lon format!');
    return;
  }

  const res = await fetch(`/route?source=${source}&destination=${dest}`);
  const pathData = await res.json();

  // Remove old route
  if (routeLayer) map.removeLayer(routeLayer);

  // Draw new route with colored segments
  routeLayer = L.polyline(pathData, {
    color: 'green', // default
    weight: 5
  }).addTo(map);

  map.fitBounds(routeLayer.getBounds());
}

// Alerts for nearby vehicles
function checkNearbyAlerts(vehicles) {
  const emergencyVehicles = vehicles.filter(v => v.type === 'emergency');
  vehicles.forEach(v => {
    emergencyVehicles.forEach(ev => {
      const dist = map.distance([v.lat, v.lng], [ev.lat, ev.lng]);
      if (dist < 500 && v.type !== 'emergency') { // 500m radius
        alert(`${v.name} is near emergency vehicle!`);
      }
    });
  });
}

// Auto refresh every 5s
setInterval(async () => {
  const vehicles = await fetchVehicles();
  updateVehicles(vehicles);
  checkNearbyAlerts(vehicles);
}, 5000);

document.getElementById('findRoute').addEventListener('click', findRoute);