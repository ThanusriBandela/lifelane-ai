package com.project.emergency.emergency_routing_webapp.controller;

import com.project.emergency.emergency_routing_webapp.model.EmergencyVehicle;
import com.project.emergency.emergency_routing_webapp.repository.EmergencyVehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vehicles")
public class HomeController {

    @Autowired
    private EmergencyVehicleRepository vehicleRepository;

    // Get all vehicles
    @GetMapping
    public List<EmergencyVehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    // Add a new vehicle
    @PostMapping
    public EmergencyVehicle addVehicle(@RequestBody EmergencyVehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }
}