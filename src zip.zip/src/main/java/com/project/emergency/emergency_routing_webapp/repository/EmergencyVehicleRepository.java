package com.project.emergency.emergency_routing_webapp.repository;

import com.project.emergency.emergency_routing_webapp.model.EmergencyVehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmergencyVehicleRepository extends JpaRepository<EmergencyVehicle, Long> {
    // Optional: add custom query methods later if needed
}