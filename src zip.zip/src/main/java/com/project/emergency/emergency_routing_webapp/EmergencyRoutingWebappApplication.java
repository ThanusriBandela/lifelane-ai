package com.project.emergency.emergency_routing_webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmergencyRoutingWebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmergencyRoutingWebappApplication.class, args);
        System.out.println("Emergency Routing Webapp is running!");
    }
}
