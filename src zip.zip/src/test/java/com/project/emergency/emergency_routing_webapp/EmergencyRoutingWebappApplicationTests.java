package com.project.emergency.emergency_routing_webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmergencyRoutingWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
